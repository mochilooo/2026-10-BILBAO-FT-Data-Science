import os
import shutil
from funciones import moverdoc, moverimg, moversoft

os.chdir("/Users/fyeray/Desktop/Descargas") # Buscar la carpeta donde trabajar
print(os.getcwd())
print(os.listdir())

moverdoc()
moverimg()
moversoft()


#/Users/fyeray/Documents/Data Science/2026-10-BILBAO-FT-Data-Science/2-Data_Analysis/3-Sources/Archivos/Practica/Programa standalone/main.py